package com.zensar.assignment.beans;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Products {
	private Data[] products;
	
	public Products() {
		
	}

	public Data[] getProducts() {
		return products;
	}

	public void setProducts(Data[] products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Products [products=" + Arrays.toString(products) + "]";
	}
	
}
