package com.zensar.assignment.rest;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zensar.assignment.beans.Data;
import com.zensar.assignment.beans.Price;
import com.zensar.assignment.beans.Product;
import com.zensar.assignment.beans.Products;

@RestController
@RequestMapping("/api")
public class ProductRestController {
	
	private static final String URL = "https://jl-nonprod-syst.apigee.net/v1/categories/600001506/products?key=2ALHCAAs6ikGRBoy6eTHA58RaG097Fma";
	private static List<Data> data = null;
	
	@GetMapping("/products")
	public List<Data> getProducts(){
		return data;
	}
	
	@GetMapping("/reduced")
	public List<Product> getReduced(){
		List<Product> result = new ArrayList();
		List<Data> mData = data.stream().filter(x -> !x.getPrice().getWas().equals("")).collect(Collectors.toList());
		mData.sort((d1,d2) -> {
	    	  if((Double.valueOf(d1.getPrice().getWas()) - Double.valueOf(d1.getPrice().getNow())) == (Double.valueOf(d2.getPrice().getWas()) - Double.valueOf(d2.getPrice().getNow()))) {
	    		  return 0;
	    	  } else  if((Double.valueOf(d1.getPrice().getWas()) - Double.valueOf(d1.getPrice().getNow())) > (Double.valueOf(d2.getPrice().getWas()) - Double.valueOf(d2.getPrice().getNow()))){
	    		  return -1;
	    	  } else {
	    		  return 1;
	    	  }
	  	  }
	    );
		for(Data x: mData) {
			Product p = new Product();
			p.setProductId(x.getProductId());
			p.setTitle(x.getTitle());
			p.setColorSwatches(x.getColorSwatches().length > 0 ? x.getColorSwatches()[0] : null);
			p.setNowPrice("�" + x.getPrice().getNow());
			p.setPriceLabel(getShowWasNow(x.getPrice()));
			result.add(p);
		}
		return result;
	}
	
	@GetMapping("/reduced/{labelType}")
	public List<Product> getReduced(@PathVariable("labelType") String labelType){
		List<Product> result = new ArrayList();
		List<Data> mData = data.stream().filter(x -> !x.getPrice().getWas().equals("")).collect(Collectors.toList());
		mData.sort((d1,d2) -> {
	    	  if((Double.valueOf(d1.getPrice().getWas()) - Double.valueOf(d1.getPrice().getNow())) == (Double.valueOf(d2.getPrice().getWas()) - Double.valueOf(d2.getPrice().getNow()))) {
	    		  return 0;
	    	  } else  if((Double.valueOf(d1.getPrice().getWas()) - Double.valueOf(d1.getPrice().getNow())) > (Double.valueOf(d2.getPrice().getWas()) - Double.valueOf(d2.getPrice().getNow()))){
	    		  return -1;
	    	  } else {
	    		  return 1;
	    	  }
	  	  }
	    );
		for(Data x: mData) {
			Product p = new Product();
			p.setProductId(x.getProductId());
			p.setTitle(x.getTitle());
			p.setColorSwatches(x.getColorSwatches().length > 0 ? x.getColorSwatches()[0] : null);
			p.setNowPrice("�" + x.getPrice().getNow());
			if(labelType.equals("1")) {
				p.setPriceLabel(getShowWasNow(x.getPrice()));
			} else if(labelType.equals("2")){
				p.setPriceLabel(getWasThenNow(x.getPrice()));
			} else if(labelType.equals("3")) {
				p.setPriceLabel(getPercDsCount(x.getPrice()));
			}
			result.add(p);
		}
		return result;
	}
	
	@PostConstruct
	private void init() {
		InputStream inStream = null;
	    try {
		      URL url = new URL(URL);
		      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		      connection.setDoOutput(true);
		      connection.setInstanceFollowRedirects(false);
		      connection.setRequestMethod("GET");
		      connection.setRequestProperty("Content-Type", "application/json");
		      connection.setRequestProperty("charset", "utf-8");
		      connection.connect();
		      inStream = connection.getInputStream();
		      ObjectMapper objectMapper = new ObjectMapper();
		      Products o = objectMapper.readValue(inStream, Products.class);
		      data = Arrays.asList(o.getProducts());
		      inStream.close();
		    } catch (IOException ex) {
		      ex.printStackTrace();
		    }
	}
	
	private String getShowWasNow(Price price) {
		return "Was �"+price.getWas()+" ,Now �"+price.getNow();
	}
	private String getWasThenNow(Price price) {
		String thenPrice=null;
		if(!price.getThen2().equals(""))
			thenPrice = price.getThen2();
		else if(!price.getThen1().equals(""))
			thenPrice = price.getThen1();
		
		return "Was �"+ price.getWas() + (thenPrice != null ? " ,Then �" + thenPrice: "") + " Now �"+price.getNow();
	}
	private String getPercDsCount(Price price) {
		Double perc = (Double.valueOf(price.getWas()) - Double.valueOf(price.getNow())) * 100 / Double.valueOf(price.getWas());
		return perc + " % off - Now �" + price.getNow() ;
	}
	
}
