package com.zensar.assignment.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Data {

	private String productId;
	private String title;
	private Price price;
	private Color[] colorSwatches;
	
	//No-Arg Constructor
	public Data() {}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Price getPrice() {
		return price;
	}

	public void setPrice(Price price) {
		this.price = price;
	}

	public Color[] getColorSwatches() {
		return colorSwatches;
	}

	public void setColorSwatches(Color[] colorSwatches) {
		this.colorSwatches = colorSwatches;
	}	
}
