package com.zensar.assignment.customDeserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.zensar.assignment.beans.Price;

public class PriceDeserializer extends StdDeserializer<Price>{

	public PriceDeserializer() {
		this(null);
	}
	public PriceDeserializer(Class<?> vc) {
		super(vc);
	}

	@Override
	public Price deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		JsonNode node = p.getCodec().readTree(p);
        Price price = new Price();
        price.setWas(node.get("was").textValue());
        price.setThen1(node.get("then1").textValue());
        price.setThen2(node.get("then2").textValue());
        price.setCurrency(node.get("currency").textValue());
        String now = "";
        if(node.get("now").get("to") != null) {
        	now = node.get("now").get("to").textValue();
        } else {
        	now = node.get("now").textValue();
        }
        price.setNow(now);
        return price;
	}

}
