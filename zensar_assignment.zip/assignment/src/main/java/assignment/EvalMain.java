package assignment;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zensar.assignment.beans.Data;
import com.zensar.assignment.beans.Products;

public class EvalMain {

	public static final String URL = "https://jl-nonprod-syst.apigee.net/v1/categories/600001506/products?key=2ALHCAAs6ikGRBoy6eTHA58RaG097Fma";
	
	public static void main(String[] args) {
		System.out
		.println(jsonGetRequest(URL));
	}
	private static String streamToString(InputStream inputStream) {
	    @SuppressWarnings("resource")
		String text = new Scanner(inputStream, "UTF-8").nextLine();
	    return text;
	  }

	  /**
	 * @param urlQueryString
	 * @return
	 */
	public static String jsonGetRequest(String urlQueryString) {
	    String json = null;
	    try {
	      URL url = new URL(urlQueryString);
	      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	      connection.setDoOutput(true);
	      connection.setInstanceFollowRedirects(false);
	      connection.setRequestMethod("GET");
	      connection.setRequestProperty("Content-Type", "application/json");
	      connection.setRequestProperty("charset", "utf-8");
	      connection.connect();
	      InputStream inStream = connection.getInputStream();
	      ObjectMapper objectMapper = new ObjectMapper();
	      Products o = objectMapper.readValue(inStream, Products.class);
	      System.out.println(o.getProducts());
	      
	      List<Data> data = Arrays.asList(o.getProducts());
	      System.out.println(data.size());
	      List<Data> mData = data.stream().filter(x -> !x.getPrice().getWas().equals("")).collect(Collectors.toList());
	      
	      mData.forEach(x -> System.out.println(x.getProductId() + " " + x.getPrice()) );
	      System.out.println("----------------------------------");
	      mData.sort((d1,d2) -> {
		    	  if((Double.valueOf(d1.getPrice().getWas()) - Double.valueOf(d1.getPrice().getNow())) == (Double.valueOf(d2.getPrice().getWas()) - Double.valueOf(d2.getPrice().getNow()))) {
		    		  return 0;
		    	  } else  if((Double.valueOf(d1.getPrice().getWas()) - Double.valueOf(d1.getPrice().getNow())) > (Double.valueOf(d2.getPrice().getWas()) - Double.valueOf(d2.getPrice().getNow()))){
		    		  return -1;
		    	  } else {
		    		  return 1;
		    	  }
	    	  }
	      );
	      mData.forEach(x -> System.out.println(x.getProductId() + " " + x.getPrice()) );
//	      json = streamToString(inStream); // input stream to string
	    } catch (IOException ex) {
	      ex.printStackTrace();
	    }
	    return json;
	  }
}
